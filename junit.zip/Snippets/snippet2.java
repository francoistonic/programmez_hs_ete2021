public class NestedTests {
    @BeforeEach
    void globalSetup() {
        System.out.println("A");
    }

    @Test
    void test1() {
        System.out.println("1");
    }

    @Test
    void test2() {
        System.out.println("2");
    }

    @Nested
    class Inside {
        @BeforeEach
        void localSetup() {
            System.out.println("B");
        }

        @Test
        void test3() {
            System.out.println("3");
        }

        @Test
        void test4() {
            System.out.println("4");
        }
    }
}
