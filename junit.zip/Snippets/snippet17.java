class BookmarkResolver implements ParameterResolver {

    @Override
    public boolean supportsParameter(ParameterContext parameterContext, ExtensionContext extensionContext) {
        // Le type d'arguments concern�s par le resolver
        return parameterContext.getParameter().getType() == Bookmark.class;
    }

    @Override
    public Object resolveParameter(ParameterContext parameterContext, ExtensionContext extensionContext) {
        if (parameterContext.isAnnotated(Article.class)) {
            return Bookmark.create("https://www.programmez.com/article/1", "Cool article");
        }
        return Bookmark.create("https://www.programmez.com", "Programmez Magazine");
    }
}

@ExtendWith(BookmarkResolver.class)
class BookmarkTest {

    @BeforeEach
    void set_up(Bookmark bookmark) {
        // Bookmark inject� : https://www.programmez.com
    }

    @Test
    void a_test(@Article Bookmark bookmark) {
        // Bookmark inject� : https://www.programmez.com/article/1
    }
}
