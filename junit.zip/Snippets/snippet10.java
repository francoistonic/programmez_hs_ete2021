public interface EqualityTest<T> {

    T createValue();
    T createOtherValue();

    @Test
    default void should_be_equal() {
        assertThat(createValue()).isEqualTo(createValue());
        assertThat(createValue().hashCode()).isEqualTo(createValue().hashCode());
    }

    @Test
    default void should_not_be_equal() {
        assertThat(createValue()).isNotEqualTo(createOtherValue());
        assertThat(createValue().hashCode()).isNotEqualTo(createOtherValue().hashCode());
    }
}
