@ParameterizedTest
@ValueSource(strings = {"Programmez", "Magazine"})
void a_simple_test(String word) {
    assertTrue(word.length() > 8);
}
