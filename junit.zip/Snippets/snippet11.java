class BookmarkTest implements EqualityTest<Bookmark> {

    @Override
    public Bookmark createValue() {
        return Bookmark.create("http://www.test.com", "name");
    }

    @Override
    public Bookmark createOtherValue() {
        return Bookmark.create("http://www.test2.com", "other name");
    }
}
