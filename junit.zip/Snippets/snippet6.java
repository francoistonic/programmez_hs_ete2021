@ParameterizedTest
@CsvSource({
    "Programmez, 10", "Magazine, 8"
})
void a_test_with_two_parameters(String word, int expectedLength) {
    assertEquals(expectedLength, word.length());
}
