@ParameterizedTest
@MethodSource("somePeople")
void a_test_with_method_source(String name, int age, Month birthMonth) {
    // ...
}

private static Stream<Arguments> somePeople() {
    return Stream.of(
            Arguments.of("Alice", 25, JUNE),
            Arguments.of("Bob", 32, AUGUST)
    );
}
