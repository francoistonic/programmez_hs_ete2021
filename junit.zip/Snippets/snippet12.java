import org.junit.jupiter.api.DisplayName;

@DisplayName("BookmarkRepository")
class BookmarkRepositoryTest {

    @Test
    @DisplayName("Should save a bookmark")
    void should_save_bookmark(Bookmark bookmark) {}

    @Nested
    @DisplayName("When a bookmark is saved")
    class WhenBookmarkIsSaved {
        @Test
        @DisplayName("it's not possible to save it again")
        void should_not_save_an_already_existent_bookmark() {}
    }
}
