@IntegrationTest
class MyIntegrationTests {/*...*/}

@ExtendWith({
        MyExtension.class,
        SpringExtension.class // Impl�ment� par Spring
})
@Retention(RetentionPolicy.RUNTIME)
@interface IntegrationTest {}
