@ParameterizedTest
@ValueSource(strings = {"JANUARY", "FEBRUARY", "MARCH"})
void a_test_with_explicit_conversion(
        @ConvertWith(MonthToNumberConverter.class) int month) {
    assertTrue(month <= 3);
}

class MonthToNumberConverter extends SimpleArgumentConverter {
    @Override
    protected Object convert(Object source, Class<?> targetType) {
        return Month.valueOf((String) source).getValue();
    }
}
