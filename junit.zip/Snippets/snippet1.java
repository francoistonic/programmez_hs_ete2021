import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.TestInstance.Lifecycle.PER_METHOD;

@TestInstance(PER_METHOD) // valeur par d�faut, pas besion de le sp�cifier
class MyTest {
    @BeforeAll
    static void avantTousLesTests() {}

    @AfterAll
    static void apresTousLesTests() {}

    @BeforeEach
    void avantChaqueTest() {}

    @AfterEach
    void apresChaqueTest() {}

    @Test
    void unTest() {}
}
