@Test
void testThrowingException() {
    Exception exception =
      assertThrows(RuntimeException.class, () -> failingCode());
    assertEquals("Failure!", exception.getMessage());
}

private void failingCode() {
    throw new RuntimeException("Failure!"));
}
