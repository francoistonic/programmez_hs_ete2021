import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.*;

@ExtendWith(MyExtension.class)
class MyIntegrationTests {

    @Test
    void test() {/*...*/}
}

class MyExtension implements BeforeAllCallback, AfterAllCallback {

    @Override
    public void beforeAll(ExtensionContext context) {
        // Pr�paration du contexte de test
    }

    @Override
    public void afterAll(ExtensionContext context) {
        // Destruction du contexte de test
    }
}
