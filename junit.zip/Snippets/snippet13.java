@CsvSource({
        "http://www.junit.org, JUnit, Testing",
        "https://www.oracle.com/fr/java/, Java, Language"
})
@DisplayName("Should create the bookmark")
@ParameterizedTest(name = "for the url {0} named {1} & tagged {2}")
void should_create_the_bookmark(String url, String name, String tag) {}
