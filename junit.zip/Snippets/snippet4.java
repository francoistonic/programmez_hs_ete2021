@Test
void groupedAssertions() {
    var list = List.of("Programmez", "Magazine", "JUnit");
    assertAll(
        () -> assertEquals(4, list.size()),
        () -> assertTrue(list.contains("Java")));
}
