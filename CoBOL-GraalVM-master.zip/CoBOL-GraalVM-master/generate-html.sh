#!/bin/bash
pandoc -f markdown -t html README.md