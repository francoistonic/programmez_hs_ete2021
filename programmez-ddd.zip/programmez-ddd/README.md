# Microservice DEMO, avec DDD et spring-boot


## Introduction
* Ce microservice, regroupe les principes de DDD et l'architecture Hexagonale.
* Il a été developpé, grâce au Framework spring-boot

## Pré-requis
* Java 8 ou supérieur

## Import dans un IDE
* Il s'agit d'un projet maven multi-modules.
* Pour l'importer, il suffit de choisir importer un projet maven dans IntelliJIDEA ou bien Eclipse.

## Lancement de l'application

### Dans un IDE
* Il s'agit d'un projet maven multi-modules.
* Il suffit de lancer la classe main `SpringBootApp`, qui est disponible dans le module exposition.

### En ligne de commande

1. Pour démarrer application, lancer dans la racine du projet: `mvn clean package`
2. Aller dans le répértoire suivant : `cd exposition/target`
3. Executer l'application: `java -jar sample-service-exposition-1.0-SNAPSHOT.jar`
2. Accéder à l'url: http://localhost:8080/

