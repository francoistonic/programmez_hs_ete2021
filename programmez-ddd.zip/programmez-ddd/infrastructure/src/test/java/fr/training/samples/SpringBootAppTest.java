package fr.training.samples;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * @author bnasslahsen
 *
 */
@SpringBootConfiguration
@ComponentScan(basePackages = { "fr.training.samples" }, lazyInit = true)
@EnableJpaRepositories
public class SpringBootAppTest {

	/**
	 * @param args
	 */
	public static void main(final String[] args) {

		SpringApplication.run(SpringBootAppTest.class, args);
	}
}
