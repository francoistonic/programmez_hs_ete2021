package fr.training.samples.infrastructure.customer.repository;

import fr.training.samples.domain.customer.entity.CustomerEntity;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author bnasslahsen
 *
 */
public interface CustomerDataJpaRepository extends JpaRepository<CustomerEntity, String> {

}
