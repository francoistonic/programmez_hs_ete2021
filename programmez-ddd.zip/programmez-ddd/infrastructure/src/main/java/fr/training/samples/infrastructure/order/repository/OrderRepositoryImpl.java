package fr.training.samples.infrastructure.order.repository;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;

import fr.training.samples.domain.common.exception.NotFoundException;
import fr.training.samples.domain.order.entity.OrderEntity;
import fr.training.samples.domain.order.repository.OrderRepository;

import org.springframework.stereotype.Repository;

/**
 * @author bnasslahsen
 *
 */
@Repository
public class OrderRepositoryImpl implements OrderRepository {

	/**
	 * orderDataJpaRepository of type OrderDataJpaRepository
	 */
	private final transient OrderDataJpaRepository orderDataJpaRepository;

	/**
	 * The EntityManager
	 */
	private final transient EntityManager entityManager;

	public OrderRepositoryImpl(OrderDataJpaRepository orderDataJpaRepository, EntityManager entityManager) {
		super();
		this.orderDataJpaRepository = orderDataJpaRepository;
		this.entityManager = entityManager;
	}

	@Override
	public OrderEntity addOrder(final OrderEntity orderEntity) {
		entityManager.persist(orderEntity);
		return orderEntity;
	}

	@Override
	public void addOrders(final List<OrderEntity> orders) {
		orderDataJpaRepository.saveAll(orders);
	}

	@Override
	public OrderEntity findOne(final String orderID) {
		return orderDataJpaRepository.findById(orderID)
				.orElseThrow(() -> new NotFoundException("Order with id:" + orderID + ", not found"));
	}

	@Override
	public Set<OrderEntity> getOrdersForCustomer(final String id) {
		return orderDataJpaRepository.getOrdersForCustomer(id);
	}
}
