package fr.training.samples.infrastructure.item.repository;

import java.util.Set;

import fr.training.samples.domain.item.entity.ItemEntity;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author bnasslahsen
 *
 */
public interface ItemDataJpaRepository extends JpaRepository<ItemEntity, String> {


	Set<ItemEntity> findByIdIn(Set<String> id);

}
