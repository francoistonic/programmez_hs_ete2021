package fr.training.samples.application.customer;

import fr.training.samples.domain.customer.CustomerVO;
import fr.training.samples.domain.customer.entity.CustomerEntity;
import fr.training.samples.domain.customer.repository.CustomerRepository;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

/**
 * @author bnasslahsen
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class CustomerManagementImplTest {

	/**
	 * customerManagement of type CustomerManagement
	 */
	@Autowired
	private transient CustomerManagement customerManagement;

	/**
	 * customerRepository of type CustomerRepository
	 */
	@MockBean
	private transient CustomerRepository customerRepository;

	@Test
	public void testCreate() {
		CustomerEntity customerEntity = initCustomerEntity();
		when(customerRepository.create(customerEntity)).thenReturn(customerEntity);
		CustomerEntity customerResultEntity = customerManagement.create(customerEntity);
		assertNotNull(customerResultEntity);
		Assert.assertEquals("NAME1", customerResultEntity.getCustomerVO().getName());
	}


	@Test
	public void testFindOne() {
		CustomerEntity customerEntity = initCustomerEntity();
		customerEntity.setId("123e4567-e89b-42d3-a456-556642440000");
		when(customerRepository.findOne("123e4567-e89b-42d3-a456-556642440000")).thenReturn(customerEntity);
		CustomerEntity customerResultEntity = customerManagement.findOne("123e4567-e89b-42d3-a456-556642440000");
		Assert.assertEquals("NAME1", customerResultEntity.getCustomerVO().getName());
	}

	@Test
	public void testUpdate() {
		CustomerEntity customerEntity = initCustomerEntity();
		customerEntity.setId("123e4567-e89b-42d3-a456-556642440000");
		when(customerRepository.update(customerEntity)).thenReturn(customerEntity);
		CustomerEntity customerResultEntity = customerManagement.update(customerEntity);
		assertNotNull(customerResultEntity);
		Assert.assertEquals("NAME1", customerResultEntity.getCustomerVO().getName());
	}

	private CustomerEntity initCustomerEntity() {
		CustomerVO customerVO = new CustomerVO("NAME1", "PASS1");
		CustomerEntity customerEntity = new CustomerEntity(customerVO);
		return customerEntity;
	}

}
