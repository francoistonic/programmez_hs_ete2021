package fr.training.samples.application.item;

import java.util.List;

import fr.training.samples.domain.item.entity.ItemEntity;

/**
 * @author bnasslahsen
 *
 */
public interface ItemManagement {

	/**
	 * @param itemEntity an itemEntity
	 * @return ItemEntity an ItemEntity
	 */
	ItemEntity addItem(ItemEntity itemEntity);

	/**
	 * @return a list of item entities
	 */
	List<ItemEntity> getAllItems();

}
