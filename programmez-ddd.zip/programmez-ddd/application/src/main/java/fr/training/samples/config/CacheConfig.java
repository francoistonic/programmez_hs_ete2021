package fr.training.samples.config;

import org.springframework.cache.annotation.EnableCaching;

/**
 * @author bnasslahsen
 *
 */
@EnableCaching
public class CacheConfig {

}
