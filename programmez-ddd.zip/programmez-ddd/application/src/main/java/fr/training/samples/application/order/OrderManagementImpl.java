package fr.training.samples.application.order;

import java.util.Set;
import java.util.stream.Collectors;

import fr.training.samples.domain.common.exception.BusinessException;
import fr.training.samples.domain.customer.entity.CustomerEntity;
import fr.training.samples.domain.customer.repository.CustomerRepository;
import fr.training.samples.domain.item.entity.ItemEntity;
import fr.training.samples.domain.item.repository.ItemRepository;
import fr.training.samples.domain.order.entity.OrderEntity;
import fr.training.samples.domain.order.repository.OrderRepository;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

/**
 * @author bnasslahsen
 *
 */
@Service
@Transactional
public class OrderManagementImpl implements OrderManagement {

	/**
	 * orderRepository of type OrderRepository
	 */
	private final transient OrderRepository orderRepository;

	/**
	 * customerRepository of type CustomerRepository
	 */
	private final transient CustomerRepository customerRepository;

	/**
	 * itemRepository of type ItemRepository
	 */
	private final transient ItemRepository itemRepository;

	public OrderManagementImpl(final OrderRepository orderRepository, final CustomerRepository customerRepository,
			final ItemRepository itemRepository) {

		super();
		this.orderRepository = orderRepository;
		this.customerRepository = customerRepository;
		this.itemRepository = itemRepository;
	}


	@Override
	public OrderEntity addOrder(final OrderEntity orderEntity) {
		final CustomerEntity customerEntity = customerRepository.findOne(orderEntity.getCustomer().getId());
		final Set<ItemEntity> items = itemRepository
				.getAllItems(orderEntity.getItems().stream().map(ItemEntity::getId).collect(Collectors.toSet()));
		if (CollectionUtils.isEmpty(items))
			throw new BusinessException("The order should contain at least one existing item");
		orderEntity.setCustomer(customerEntity);
		orderEntity.setItems(items);
		return orderRepository.addOrder(orderEntity);
	}

	@Override
	public OrderEntity findOne(final String orderID) {
		return orderRepository.findOne(orderID);
	}

	@Override
	public Set<OrderEntity> getOrdersForCustomer(final String customerID) {
		return orderRepository.getOrdersForCustomer(customerID);
	}
}
