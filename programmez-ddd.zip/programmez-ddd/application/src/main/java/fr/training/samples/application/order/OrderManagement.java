package fr.training.samples.application.order;

import java.util.Set;

import fr.training.samples.domain.order.entity.OrderEntity;

/**
 * @author bnasslahsen
 *
 */
public interface OrderManagement {

	/**
	 * @param order the order entity
	 * @return an OrderEntity
	 */
	OrderEntity addOrder(OrderEntity order);

	/**
	 * @param orderID the order id
	 * @return an OrderEntity
	 */
	OrderEntity findOne(String orderID);

	/**
	 * @param customerID
	 * @return a Set of OrderEntity
	 */
	Set<OrderEntity> getOrdersForCustomer(String customerID);

}
