package fr.training.samples.application.customer;

import fr.training.samples.domain.customer.entity.CustomerEntity;

/**
 * @author bnasslahsen
 *
 */
public interface CustomerManagement {

	/**
	 * @param customer a CustomerEntity
	 * @return a CustomerEntity
	 */
	CustomerEntity create(CustomerEntity customer);

	/**
	 * @param customerID a customer identifier
	 * @return a CustomerEntity
	 */
	CustomerEntity findOne(String customerID);

	/**
	 * @param customerEntity a CustomerEntity
	 * @return a CustomerEntity
	 */
	CustomerEntity update(CustomerEntity customerEntity);

}
