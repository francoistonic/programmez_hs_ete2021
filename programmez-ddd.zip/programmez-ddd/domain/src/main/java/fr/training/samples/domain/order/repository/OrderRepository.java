package fr.training.samples.domain.order.repository;

import java.util.List;
import java.util.Set;

import fr.training.samples.domain.order.entity.OrderEntity;

/**
 * @author bnasslahsen
 *
 */
public interface OrderRepository {

	/**
	 * @param order
	 * @return
	 */
	OrderEntity addOrder(OrderEntity order);

	/**
	 * @param orders
	 */
	void addOrders(List<OrderEntity> orders);

	/**
	 * @param orderID
	 * @return
	 */
	OrderEntity findOne(String orderID);

	/**
	 * @param customerID
	 * @return
	 */
	Set<OrderEntity> getOrdersForCustomer(String customerID);

}
