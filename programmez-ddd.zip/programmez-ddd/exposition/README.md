# Pour tester 

Accès au swagger sans WLC
- http://localhost:8080/swagger-ui.html
URL de test sans WLC
- http://localhost:8080/api/items

Accès au swagger wlc:
- http://localhost:9080/sample-service-exposition/api/items
URL de test avec WLC
- http://localhost:9080/sample-service-exposition/swagger-ui.html