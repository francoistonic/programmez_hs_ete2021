package fr.training.samples.common;

public class ErrorModel {

}
