package fr.training.samples.exposition.item.rest;

import fr.training.samples.common.AbstractMapper;
import fr.training.samples.domain.item.ItemVO;
import fr.training.samples.domain.item.entity.ItemEntity;

import org.springframework.stereotype.Component;

/**
 * @author bnasslahsen
 *
 */
@Component
public class ItemMapper implements AbstractMapper<ItemDTO, ItemEntity> {

	@Override
	public ItemDTO mapToDto(ItemEntity entity) {
		ItemDTO itemDTO = new ItemDTO();
		itemDTO.setItemID(entity.getId());
		if (entity.getItemVO() != null) {
			itemDTO.setDescription(entity.getItemVO().getDescription());
			itemDTO.setPrice(entity.getItemVO().getPrice());
		}
		return itemDTO;
	}

	@Override
	public ItemEntity mapToEntity(ItemDTO dto) {
		ItemEntity itemEntity = new ItemEntity();
		ItemVO itemVO = new ItemVO(dto.getDescription(), dto.getPrice());
		itemEntity.setItemVO(itemVO);
		itemEntity.setId(dto.getItemID());
		return itemEntity;
	}

	public ItemEntity mapToEntity(ItemLightDTO dto) {
		ItemEntity itemEntity = new ItemEntity();
		ItemVO itemVO = new ItemVO(dto.getDescription(), dto.getPrice());
		itemEntity.setItemVO(itemVO);
		return itemEntity;
	}

}