package fr.axance.tech.demo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloDockerController {

    @RequestMapping("/")
    public String index() {
        return "Greetings from Creatiev Tech";
    }

}
