package fr.axance.tech.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApplicationStarterTests {

	@Test
	void contextLoads() {
	}

}
