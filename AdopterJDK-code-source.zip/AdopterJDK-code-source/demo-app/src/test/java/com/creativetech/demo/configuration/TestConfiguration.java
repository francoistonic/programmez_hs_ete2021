package com.creativetech.demo.configuration;

import java.util.List;

import javax.xml.bind.JAXBException;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.config.EnableWebFlux;

import com.creativetech.demo.helper.JaxbHelper;
import com.creativetech.demo.model.AdressBook;

@Configuration
@EnableWebFlux
@ComponentScan(basePackages = {"com.creativetech.demo"})
public class TestConfiguration {

	@Bean
	public JaxbHelper getJaxbHelper() throws JAXBException {
		return new JaxbHelper(AdressBook.class);
	}
	
	@Bean
	public DozerBeanMapper getDozerMapper(@Value("${demo.dozer-mapping-path}") String mappingFilePath) {
		return new DozerBeanMapper(List.of(mappingFilePath));
	}
}
