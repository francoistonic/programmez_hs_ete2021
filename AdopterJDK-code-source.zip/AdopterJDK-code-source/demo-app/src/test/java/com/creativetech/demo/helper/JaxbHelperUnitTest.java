package com.creativetech.demo.helper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.List;

import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ResourceLoader;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;

import com.creativetech.demo.model.AdressBook;
import com.creativetech.demo.model.Contact;

@DisplayName("Jaxb Helper Test")
@TestMethodOrder(OrderAnnotation.class)
@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest
@ExtendWith(SpringExtension.class)
class JaxbHelperUnitTest {

	@Mock
	private ContentHandler handler;

	@Autowired
	private JaxbHelper jaxbHelper;
	
	@Autowired
	private ResourceLoader resourceLoader;

	private AdressBook adressBook;

	@BeforeAll
	public void init() {
		adressBook = new AdressBook();
		EasyRandom easyRandom = new EasyRandom();
		adressBook.setContacts(List.of(easyRandom.nextObject(Contact.class), easyRandom.nextObject(Contact.class),
				easyRandom.nextObject(Contact.class)));
	}

	@Test
	@Order(1)
	void marshall_object_to_xml_elements() throws Exception {
		jaxbHelper.writeToContentHandler(adressBook, handler);
		verify(handler).startDocument();
		verify(handler).startElement(anyString(), eq("adressBook"), anyString(), any(Attributes.class));
		verify(handler, times(3)).startElement(anyString(), eq("entry"), anyString(), any(Attributes.class));
		verify(handler, times(3)).startElement(anyString(), eq("name"), anyString(), any(Attributes.class));
		verify(handler, times(3)).startElement(anyString(), eq("email"), anyString(), any(Attributes.class));
		verify(handler, times(3)).startElement(anyString(), eq("phone"), anyString(), any(Attributes.class));
		verify(handler, times(3)).startElement(anyString(), eq("adress"), anyString(), any(Attributes.class));
		verify(handler, times(3)).startElement(anyString(), eq("line1"), anyString(), any(Attributes.class));
		verify(handler).endDocument();
	}

	@Test
	@Order(2)
	void unmarshall_xml_file_to_object() throws Exception {
		AdressBook adressBook = jaxbHelper.readFromStream(resourceLoader.getResource("classpath:/data/address-book.xml").getInputStream());
		assertThat(adressBook).isNotNull().satisfies(elements -> {
			assertThat(elements.getContacts()).isNotEmpty().hasSize(5);
			assertThat(elements.getContacts()).anySatisfy(contact-> {
				assertThat(contact.getId()).isEqualTo("1");
				assertThat(contact.getName()).isEqualTo("Creative Tech");
				assertThat(contact.getEmail()).isEqualTo("creative.tech@devoteam.com");
				assertThat(contact.getAdress()).isNotNull();
				assertThat(contact.getAdress().getZipCode()).isEqualTo("75000");
			});
		});
	}
}
