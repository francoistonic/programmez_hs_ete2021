package com.creativetech.demo.api;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.creativetech.demo.configuration.TestConfiguration;
import com.creativetech.demo.vo.ContactVo;


@DisplayName("Api Test")
@TestMethodOrder(OrderAnnotation.class)
@ExtendWith(SpringExtension.class)
@WebFluxTest(controllers = ApiController.class)
@Import(TestConfiguration.class)
class ApiControllerUnitTest {
	
	@Autowired
    private WebTestClient webTestClient;
	
	@Test
	@Order(1)
	void consume_greeting_resource_with_success() {
		
		webTestClient.get()
        .uri("/hello")
        .exchange()
        .expectStatus().isOk()
        .expectBody(String.class)
        .isEqualTo("Greating form Creative Technology");
	}
	
	@Test
	@Order(2)
	void consume_contacts_resource_with_success() {
		
		List<ContactVo> contacts = webTestClient.get()
        .uri("/contacts")
        .exchange()
        .expectStatus().isOk().expectBodyList(ContactVo.class).returnResult().getResponseBody();
		 
		assertThat(contacts).isNotNull().isNotEmpty().anySatisfy(contact -> {
			assertThat(contact.getId()).isEqualTo("1");
			assertThat(contact.getName()).isEqualTo("Creative Tech");
			assertThat(contact.getEmail()).isEqualTo("creative.tech@devoteam.com");
			assertThat(contact.getAdress()).isNotNull();
			assertThat(contact.getAdress()).isEqualTo("line 1, line 2, line 2, 75000, Paris, France");
		});
	}

}
