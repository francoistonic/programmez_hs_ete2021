package com.creativetech.demo.helper;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.stream.Collectors;

import org.dozer.DozerBeanMapper;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ResourceLoader;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.creativetech.demo.model.AdressBook;
import com.creativetech.demo.model.Contact;
import com.creativetech.demo.vo.ContactVo;

@DisplayName("Dozer Mapper Test")
@TestMethodOrder(OrderAnnotation.class)
@TestInstance(Lifecycle.PER_CLASS)
@SpringBootTest
@ExtendWith(SpringExtension.class)
class DozerMapperUnitTest {

	@Autowired
	private DozerBeanMapper mapper;

	@Autowired
	private JaxbHelper jaxbHelper;

	@Autowired
	private ResourceLoader resourceLoader;

	private AdressBook adressBook;

	private List<ContactVo> contacts;

	@BeforeAll
	public void init() {
		adressBook = new AdressBook();
		EasyRandom easyRandom = new EasyRandom();
		adressBook.setContacts(List.of(easyRandom.nextObject(Contact.class), easyRandom.nextObject(Contact.class),
				easyRandom.nextObject(Contact.class)));
	}

	@Test
	@Order(1)
	void map_list_contact_to_list_contactvo() throws Exception {
		AdressBook adressBook = jaxbHelper
				.readFromStream(resourceLoader.getResource("classpath:/data/address-book.xml").getInputStream());
		contacts = adressBook.getContacts().stream().map(from -> {
			try {
				return mapper.map(from, ContactVo.class, "contact-mapper");
			} catch (Exception e) {
			}
			return null;
		}).collect(Collectors.toList());
		assertThat(contacts).isNotNull().isNotEmpty().anySatisfy(contact -> {
			assertThat(contact.getId()).isEqualTo("1");
			assertThat(contact.getName()).isEqualTo("Creative Tech");
			assertThat(contact.getEmail()).isEqualTo("creative.tech@devoteam.com");
			assertThat(contact.getAdress()).isNotNull();
			assertThat(contact.getAdress()).isEqualTo("line 1, line 2, line 2, 75000, Paris, France");
		});
	}
}
