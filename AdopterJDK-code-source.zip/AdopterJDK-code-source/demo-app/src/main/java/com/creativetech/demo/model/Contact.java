package com.creativetech.demo.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.Data;

@Data
@XmlRootElement(name = "entry")
@XmlType(propOrder = { "name", "email", "phoneNumber", "adress" })
@XmlAccessorType(XmlAccessType.FIELD)
public class Contact implements Serializable{

	static final long serialVersionUID = -1850735464006710337L;
	
	@XmlAttribute
	private String id;
	
	private String name;
	
	private String email;
	
	@XmlElement(name = "phone")
	private String phoneNumber;
	
	
	private Adress adress;
}
