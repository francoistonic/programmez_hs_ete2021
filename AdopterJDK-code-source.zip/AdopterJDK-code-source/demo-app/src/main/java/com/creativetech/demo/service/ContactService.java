package com.creativetech.demo.service;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import javax.xml.bind.JAXBException;

import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.creativetech.demo.helper.JaxbHelper;
import com.creativetech.demo.model.AdressBook;
import com.creativetech.demo.vo.ContactVo;

@Service
public class ContactService {

	private ResourceLoader resourceLoader;
	private DozerBeanMapper mapper;
	private JaxbHelper jaxbHelper;
	private String xmlFilePath;

	public ContactService(ResourceLoader resourceLoader, DozerBeanMapper mapper, JaxbHelper jaxbHelper,
			@Value("${demo.xml-file-path}") String xmlFilePath) {
		super();
		this.resourceLoader = resourceLoader;
		this.mapper = mapper;
		this.jaxbHelper = jaxbHelper;
		this.xmlFilePath = xmlFilePath;
	}

	public List<ContactVo> retrieveContacts() throws JAXBException, IOException {
		AdressBook adressBook = jaxbHelper.readFromStream(resourceLoader.getResource(xmlFilePath).getInputStream());
		return adressBook.getContacts().stream().map(from -> {
			try {
				return mapper.map(from, ContactVo.class, "contact-mapper");
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}).collect(Collectors.toList());
	}
}
