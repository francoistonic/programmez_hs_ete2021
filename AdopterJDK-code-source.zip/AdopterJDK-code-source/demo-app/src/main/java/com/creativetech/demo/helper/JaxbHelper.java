package com.creativetech.demo.helper;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.xml.sax.ContentHandler;

public class JaxbHelper {

private JAXBContext context;
	
	public JaxbHelper(JAXBContext context) {
		super();
		this.context = context;
	}
	
	public JaxbHelper(Class<?> ... classes) throws JAXBException{
		this.context = JAXBContext.newInstance(classes);
	}
	
	@SuppressWarnings("unchecked")
	public <T> T readFromFile(File path) throws JAXBException {
		return (T) context.createUnmarshaller().unmarshal(path);
	}
	
	@SuppressWarnings("unchecked")
	public <T> T readFromStream(InputStream stream) throws JAXBException {
		return (T) context.createUnmarshaller().unmarshal(stream);
	}
	
	@SuppressWarnings("unchecked")
	public <T> T readFromXmlString(String xml) throws JAXBException{
		return (T) context.createUnmarshaller().unmarshal(new ByteArrayInputStream(xml.getBytes()));
	}
	
	public <T> void writeToFile(T objectValue, File path) throws JAXBException {
		 context.createMarshaller().marshal(objectValue, path);
	}
	
	public <T> void writeToContentHandler(T objectValue, ContentHandler handler ) throws JAXBException {
		 context.createMarshaller().marshal(objectValue, handler);
	}
	
}
