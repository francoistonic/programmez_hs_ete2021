package com.creativetech.demo.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import lombok.Data;

@Data
@XmlRootElement(name = "adress")
@XmlType(propOrder = { "line1", "line2", "line3", "zipCode", "state", "country"})
@XmlAccessorType(XmlAccessType.FIELD)
public class Adress implements Serializable {
	
	static final long serialVersionUID = 2177858940792251003L;
	
	private String line1;
	
	private String line2;	

	private String line3;
	
	@XmlElement(name = "zip")
	private String zipCode;
	
	private String state;
	
	private String country;
	
}
