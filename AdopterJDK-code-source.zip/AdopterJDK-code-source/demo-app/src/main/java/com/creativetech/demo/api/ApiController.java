package com.creativetech.demo.api;

import java.io.IOException;

import javax.xml.bind.JAXBException;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.creativetech.demo.service.ContactService;
import com.creativetech.demo.vo.ContactVo;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@Slf4j
public class ApiController {

	private ContactService contactService;

	public ApiController(ContactService contactService) {
		this.contactService = contactService;
	}

	@GetMapping(path = "/hello", produces = { MediaType.APPLICATION_JSON_VALUE })
	public Mono<String> greating() {
		log.debug("Consuming Hello endpoint : String body response => Greeting form Creative Technology");
		return Mono.just("Greeting form Creative Technology");
	}

	@GetMapping(path = "/contacts", produces = { MediaType.APPLICATION_JSON_VALUE })
	public Flux<ContactVo> getContactList() throws JAXBException, IOException {
		log.debug("Consuming Contacts endpoint");
		return Flux.fromIterable(contactService.retrieveContacts());
	}

}
