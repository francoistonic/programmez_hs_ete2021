package com.creativetech.demo.converter;

import java.util.StringJoiner;

import org.dozer.CustomConverter;

import com.creativetech.demo.model.Adress;

public class AdressToStringConverter implements CustomConverter {

	@Override
	public Object convert(Object existingDestinationFieldValue, Object sourceFieldValue, Class<?> destinationClass,
			Class<?> sourceClass) {

		if (sourceFieldValue == null) {
			return null;
		}

		if (sourceFieldValue instanceof Adress) {
			StringJoiner adress = new StringJoiner(", ");
			adress.add(((Adress) sourceFieldValue).getLine1());
			adress.add(((Adress) sourceFieldValue).getLine2());
			adress.add(((Adress) sourceFieldValue).getLine2());
			adress.add(((Adress) sourceFieldValue).getZipCode());
			adress.add(((Adress) sourceFieldValue).getState());
			adress.add(((Adress) sourceFieldValue).getCountry());
			return adress.toString();
		}
		return null;
	}

}
