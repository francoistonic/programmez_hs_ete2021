package com.shma;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

/*
For a given natural number greater than zero return:
* "fizz" if the number is dividable by 3
* "buzz" if the number is dividable by 5
* "fizzbuzz" if the number is dividable by 15
* the same number if no other requirement is fulfilled
 */

public class FizzBuzzTest {
    FizzBuzz fizzBuzz;

    @Before
    public void init() {
        fizzBuzz = new FizzBuzz();
    }

    @Test
    public void should_return_buzz_if_the_number_is_dividable_by_3() {
        fizzBuzz.getResult(3);
        Assert.assertTrue(true);
    }

    @Test
    public void should_return_buzz_if_the_number_is_dividable_by_5() {
        String result = fizzBuzz.getResult(5);
    }

    @Test
    public void should_return_buzz_if_the_number_is_dividable_by_15() {
        Assert.assertEquals("FizzBuzz", fizzBuzz.getResult(15));
        Assert.assertEquals("FizzBuzz", fizzBuzz.getResult(30));
    }

    @Test
    public void should_return_the_same_number_if_no_other_requirement_is_fulfilled() {
        Assert.assertEquals(fizzBuzz.getResult(1).getClass(), String.class);
    }
}

